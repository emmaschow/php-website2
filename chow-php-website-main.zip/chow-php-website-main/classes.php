<?php
$pageTitle = 'Classes';
$bkgdImage = 'chapel-hill.jpg';
include 'includes/header.php'; // Don't change this.
?>

<!-- THIS IS THE UNIQUE CONTENT FOR EACH PAGE! -->

<?php include 'includes/class-nav.php'; ?>
<h1>Fall 2022 Courses</h1>

<p>Click on each link to learn more about my classes!</p>

      <img class="img-fluid" src="images/class.jpg" alt="Classroom">


<?php include 'includes/footer.php'; // Don't Change this?>
