<?php
$pageTitle = 'INLS 161';
$bkgdImage = 'website.jpg';
include 'includes/header.php'; // Don't change this.
?>



<?php include 'includes/class-nav.php'; ?>
<h1>INLS 161</h1>

<a href="https://ils.unc.edu/courses/2022_fall/inls161_001/">INLS 161</a>
<p>INLS 161 explores the Tools and concepts necessary for information literacy</p>



<?php include 'includes/footer.php'; // Don't Change this
?>
