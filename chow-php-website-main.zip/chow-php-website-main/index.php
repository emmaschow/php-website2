<?php
$pageTitle = 'Home';
$bkgdImage = 'Mountains.jpg';
include 'includes/header.php';

?>

<!-- THIS IS THE UNIQUE CONTENT FOR EACH PAGE! -->

<h1>Home</h1>
<p>Welcome to my website! I'm Emma, a 19-year-old student at the University of North Carolina at Chapel Hill.</p>
       	    
      <img class="img-fluid" src="images/greensboro.jpg" alt="Greensboro building">


<?php  // include footer
include 'includes/footer.php'; ?>
