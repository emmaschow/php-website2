    </div>
   </div>
  </div>
 </div>
</div>


 <footer class="footer">
  <div class="container">
   <span>Emma Chow.</span>
  </div>
   </footer>

  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
 </body>
</html>
