<!-- CLASS SUB-NAVIGATION CODE FOR ALL PAGES! -->

<ul class="nav nav-pills">
 <li class="nav-item"><a class="nav-link<?php if ($pageTitle =="INLS 161") {?> active <?php } ?>" href="inls-161.php">INLS 161</a></li>
 <li class="nav-item"><a class="nav-link<?php if ($pageTitle =="INLS 201") {?> active <?php } ?>" href="inls-201.php">INLS 201</a></li>
 <li class="nav-item"><a class="nav-link<?php if ($pageTitle =="PSYC 250") {?> active <?php } ?>" href="psyc-250.php">PSYC 250</a></li>
 <li class="nav-item"><a class="nav-link<?php if ($pageTitle =="PSYC 270") {?> active <?php } ?>" href="psyc-270.php">PSYC 270</a></li>
</ul>
