<?php
$pageTitle = 'INLS 201';
$bkgdImage = 'information.jpg';
include 'includes/header.php'; // Don't change this.
?>

<?php include 'includes/class-nav.php'; ?>
<h1>INLS 201</h1>

<a href="https://aeshin.org/teaching/inls-201/2022/fa/schedule/#next">INLS 201</a> 
<p>This class examines the foundations of information science.</p>

<?php include 'includes/footer.php'; // Don't Change this
?>
