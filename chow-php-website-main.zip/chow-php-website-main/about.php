<?php
$pageTitle = 'About';
$bkgdImage = 'Rocks.jpg';
include 'includes/header.php';
?>

<!-- THIS IS THE UNIQUE CONTENT FOR EACH PAGE! -->

 <h1>About</h1>

<p>Hi there, I am Emma Chow, a second year student at UNC-Chapel Hill in North Carolina. I am 19-years-old and orginally from Greensboro, NC. I am a dedicated student studying Information science and Psychology. Ever since I was a kid, I've wanted to explore how information systems function and how they can be ultized to help people. As an undergraduate, I am continuing to explore my chosen majors and hope to expand my knowledage as I progess at UNC. When I am not in the classroom, I love to hike, play with my three dogs, and see my friends and family. </p>

      <img class="img-fluid" src="images/psyc.jpg" alt="Psychology books">



<?php  // include footer
include 'includes/footer.php'; ?>
