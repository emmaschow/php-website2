<?php
$pageTitle = 'PSYC 270';
$bkgdImage = 'research.jpg';
include 'includes/header.php'; // Don't change this.
?>
<?php include 'includes/class-nav.php'; ?>
<h1>PSYC 270</h1>
<a href="https://sakai.unc.edu/portal/site/572a8196-1653-4e68-9b66-413e0f14c4d3"> Link to PSYC 270</a>
<p>This class examines research methods in psychology.</p>

<?php include 'includes/footer.php'; // Don't Change this
?>
