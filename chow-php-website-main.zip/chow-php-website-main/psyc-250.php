<?php
$pageTitle = 'PSYC 250';
$bkgdImage = 'child.jpg';
include 'includes/header.php'; // Don't change this.
?>
<?php include 'includes/class-nav.php'; ?>
<h1>PSYCH 250</h1>

<p>This class examines the basics of child development.</p>

<?php include 'includes/footer.php'; // Don't Change this
?>
