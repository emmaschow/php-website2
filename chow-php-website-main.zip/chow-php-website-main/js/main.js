document.getElementById("js-example").innerHTML = "This is here because of javascript!";
